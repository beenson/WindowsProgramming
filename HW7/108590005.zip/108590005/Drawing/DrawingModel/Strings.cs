﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrawingModel
{
    public static class Strings
    {
        public const string LEFT = "(";
        public const string RIGHT = ")";
        public const string COMMA = ",";
        public const string SPACE = " ";
    }
}
