﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrawingModel
{
    public static class Strings
    {
        public const string SPACE = " ";

        // Google Drive
        public const string APPLICATION_NAME = "DrawAnywhere";
        public const string CLIENT_SECRET_FILE_NAME = "clientSecret.json";
        public const string FILE_CONTENT_TYPE = "application/json";
        public const string FILE_NAME = "Shapes.json";
        // Point
        public const string LEFT_BRACKET = "(";
        public const string RIGHT_BRACKET = ")";
        public const string COMMA = ",";
        // Json
        public const string SHAPES = "Shapes";
        public const string ID = "Id";
        public const string SHAPE_TYPE = "Type";
        public const string LEFT = "Left";
        public const string RIGHT = "Right";
        public const string UPPER = "Upper";
        public const string LOWER = "Lower";
        public const string SHAPE1 = "Shape1";
        public const string SHAPE2 = "Shape2";
        // Error
        public const string SHAPE_NOT_FOUND = "ShapeNotFound";
        public const string FILE_NOT_EXIST = "FileNotExist";
    }
}
