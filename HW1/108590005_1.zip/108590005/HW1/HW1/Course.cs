﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;

namespace homework1
{
    public class Course
    {
        private List<string> _data = new List<string>();

        public Course(HtmlNodeCollection nodeTableDatas)
        {
            foreach (var nodeTableData in nodeTableDatas)
            {
                _data.Add(nodeTableData.InnerText.Trim());
            }
        }

        //取得課程資料
        public List<string> GetData()
        {
            return _data;
        }
    }
}
